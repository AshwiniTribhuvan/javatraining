package com.example.crudapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudappApplicationTests {

	@Test
	void contextLoads() {
	}

}
